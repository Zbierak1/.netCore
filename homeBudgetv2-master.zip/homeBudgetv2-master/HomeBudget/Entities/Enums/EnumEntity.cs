﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeBudget.Enums
{
    public enum Relations
    {
        Father = 1,
        Mother = 2,
        Son = 3,
        Daughter = 4
    }
}
