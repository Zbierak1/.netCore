﻿using System.Collections.Generic;

namespace HomeBudget.Models.People
{
    public class PeopleListViewModel
    {
        public IList<PersonModel> People{ get; set; }
    }
}
